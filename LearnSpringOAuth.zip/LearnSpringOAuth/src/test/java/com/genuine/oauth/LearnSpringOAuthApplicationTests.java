package com.genuine.oauth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LearnSpringOAuthApplicationTests {

	@Test
	void contextLoads() {
	}

}
